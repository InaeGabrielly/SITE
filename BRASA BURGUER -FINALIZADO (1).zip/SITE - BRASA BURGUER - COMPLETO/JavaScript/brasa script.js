//SCRIPT DA JANELA MODAL DE CADASTRO 
var tela= document.getElementById("pag-inteira1")
var fec=document.getElementById ("fechar1")
fec.addEventListener("click",fechar1)

function abrir1(){
   tela.classList.remove("desaparecer") 
   tela.classList.add("aparecer")
}

function fechar1(){
   tela.classList.remove("aparecer") 
   tela.classList.add("desaparecer")
   
 }

//  SCRIPT DA JANELA MODAL DE LOGIN
 var telas= document.getElementById ("pag-inteira2")

function abrir2(){
   telas.classList.remove ("desaparecer") 
   telas.classList.add ("aparecer")
}

function fechar2(){
    telas.classList.remove ("aparecer") 
    telas.classList.add ("desaparecer")
 }