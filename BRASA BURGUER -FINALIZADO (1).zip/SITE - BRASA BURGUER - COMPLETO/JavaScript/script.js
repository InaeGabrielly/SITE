// ------------------------LOGICA DO BOTAO DE INCREMENTO--------------------------------- 
const numeros = document.querySelectorAll("[data-js=num]");
const buttonsAdd = document.querySelectorAll("[data-js=add]");
const buttonsSub = document.querySelectorAll("[data-js=sub]");

for (let i = 0; i < buttonsAdd.length; i++) {
    buttonsAdd[i].addEventListener("click", () => {
        let valor = parseInt(numeros[i].innerText) + 1;
        numeros[i].innerText = valor;
        produtos[i].quantidade=valor;
    });
}

for (let i = 0; i < buttonsSub.length; i++) {
    buttonsSub[i].addEventListener("click", () => {
        let valor = parseInt(numeros[i].innerText) - 1;
        
        if(valor >=  0) {
            numeros[i].innerText = valor;
            produtos.quantidade=valor;
        }
    });
}




// ------------------------------------------------------------

const produtos = [


    { tipo:"hamburguer", foto:"imagem/oferta1_double.jpg",      nome:"X-DOUBLE (2 POR 1)",                          descricao:"Pão com gergelim, tomate, alface, carne, mussarela, cebola roxa, pimentão, pepino.",                                                                                     valor:30 , quantidade:0  },
    { tipo:"hamburguer", foto:"imagem/oferta2__3hamb.jpg",      nome:"DA CASA (2 PELA METADE DO PREÇO)",            descricao:"Pão com queijo por cima, cream cheese, carne de boi 160g recheada com queijo, picles, cebola roxa, alface, tomate.",                                                     valor:50 , quantidade:0  },
    { tipo:"hamburguer", foto:"imagem/combo1_hambata.jpg",      nome:"3 PRO-BURGUER ACOMPANHADO COM BATATA" ,       descricao:"Pão com gergelim e uma fatia extra de pão no meio, cebola empanada, tomate, queijo, 2 carnes de boi 160g, alface, cebola picada e picles." ,                             valor:70 , quantidade:0  },
    { tipo:"hamburguer", foto:"imagem/combo2_hamb.jpg",         nome:"2 DUPLO ESPECIAL" ,                           descricao:"Pão de gergelim, 2 carnes de boi 160g, queijo cheddar, bacon, pimentão, alface." ,                                                                                       valor:50 , quantidade:0  },
    { tipo:"hamburguer", foto:"imagem/hamburguer1_one.jpg",     nome:"ONE BURGUER",                                 descricao:"Pão sem gergelim, bacon, queijo cheddar, carne de boi 160g, alface, tomate.",                                                                                            valor:23 , quantidade:0  },
    { tipo:"hamburguer", foto:"imagem/hamburguer2_pro.jpg",     nome:"PRO-BURGUER",                                 descricao:"Pão com gergelim e uma fatia extra de pão no meio, cebola empanada, tomate, queijo, 2 carnes de boi 160g, alface, cebola picada e picles.",                              valor:32 , quantidade:0  },
    { tipo:"hamburguer", foto:"imagem/hamburguer3_picanha.jpg", nome:"PICANHA",                                     descricao:"Pão com gergelim, bacon, queijo cheddar, 2 carnes de boi 160g, alface, tomate.",                                                                                         valor:38 , quantidade:0  },
    { tipo:"hamburguer", foto:"imagem/hamburguer4_duo.jpg",     nome:"DUO",                                         descricao:"Pão com gergelim, alface, tomate, cebola roxa, mussarela, cream cheese, ketchup, carne de boi 160g.",                                                                    valor:20 , quantidade:0  },
    { tipo:"hamburguer", foto:"imagem/hamburguer5_simple.jpg",  nome:"SIMPLE",                                      descricao:"Pão sem gergelim, bacon, queijo cheddar, 1 carne de boi 160g (opção de pão integral).",                                                                                  valor:20 , quantidade:0  },
    { tipo:"hamburguer", foto:"imagem/hamburguer6_queijos.jpg", nome:"3 QUEIJOS",                                   descricao:"Pão com gergelim, 2 carnes 160g, mussarela, queijo cheddar, parmesão, alface, tomate, cebola roxa.",                                                                     valor:35 , quantidade:0  },
    { tipo:"porcao",     foto:"imagem/porçao1_batacheddar.png", nome:"BATATA FRITA COM CHEDDAR E BACON",            descricao:"Porção de Batata Frita com cheddar da casa e bacon cortado em pedaços.",                                                                                                 valor:20 , quantidade:0  },
    { tipo:"porcao",     foto:"imagem/porçao2_bata_frango.png", nome:"BATATA RUSTICA E FRANGO",                     descricao:"Batata frita acompanhada de frango empanado e temperado,e  ketchup.",                                                                                                    valor:25 , quantidade:0  },
    { tipo:"porcao",     foto:"imagem/porçao3_salgados.jpg",    nome:"MINI SALGADOS",                               descricao:"Pequena porção de 4 tipos de salgados (contendo 6 mini-pasteis de carne, 8 bolinhas de queijo, 8 enroladinhos de queijo com alho poró e 8 enroladinhos de calabresa).",  valor:25 , quantidade:0  },
    { tipo:"suco",       foto:"imagem/Bebida1_suco.jpg",        nome:"SUCO NATURAL",                                descricao:"Suco natural de diversos sabores (Laranja, Morango, Goiaba, Maracuja, Limonada Suiça e Abacaxi com hotelã).",                                                            valor:4  , quantidade:0  },
    { tipo:"bebida",     foto:"imagem/caipirinha.jpg",          nome:"CAIPIRINHA",                                  descricao:"Coquetel álcoolico feito com cachaça, limão, açúcar e gelo.",                                                                                                            valor:6  , quantidade:0  },
    { tipo:"suco",       foto:"imagem/bebida3_drink.jpeg",      nome:"DRINK`S",                                     descricao:"Drink feito com frutas e gin (Laranja, Morango, Goiaba, Maracuja, Limonada Suiça e Abacaxi com hotelã).",                                                                valor:8  , quantidade:0  },
    { tipo:"sobremesa",  foto:"imagem/sobremesa1_tortaL.jpg",   nome:"CHEESECAKE DE LIMÃO",                         descricao:"Uma fatia de Cheesecake feito com recheio cremoso sabor limão.",                                                                                                         valor:12 , quantidade:0  },
    { tipo:"sobremesa",  foto:"imagem/sobremesa2_pave.jpg",     nome:"PAVÊ CREMOSO COM CHOCOLATE",                  descricao:"Pave feito com mousse de chocolate e recheado com biscoito,cobertura de leite condensado e amendoas.",                                                                   valor:10 , quantidade:0  },
    { tipo:"sobremesa",  foto:"imagem/sobremesa3_moussem.jpg",  nome:"MOUSSE DE MARACUJÁ",                          descricao:"Mousse de maracujá feito com a fruta.",                                                                                                                                  valor:12 , quantidade:0  },
    { tipo:"sobremesa",  foto:"imagem/sobremesa4_bolosorv.jpg", nome:"PETIT GÂTEAU",                                descricao:"Petit Gâteau com sorvete, morango e calda de chocolate.",                                                                                                                valor:15 , quantidade:0  }
    
];

const acrescentar = [
    {nome:"Carne de boi 160g",valor:5},
    {nome:"Carne de picanha",valor:8},
    {nome:"Bacon",valor:0},
    {nome:"Cheddar",valor:0},
    {nome:"Ovo",valor:0},
    {nome:"Salada",valor:0}
]


// ------------------------LOGICA DO MODAL CONTINNUAR ----------------------------
var tela = document.getElementById("modal-fundo");
var total= 0
var totalfinal = 0



function continuar(){
     
    tela.classList.remove("desaparecer");
    tela.classList.add("aparecer");

    Carrinho()
    for (let i = 0; i < carrinho.length; i++){

        if(carrinho[i]!=undefined){
            if(produtos[i].tipo == "hamburguer"){
                
                    document.querySelector("#conteudo-repetir").innerHTML+=`<section class="conteudo-dinamico cor-de-fundo-modal"> <section><article class="conteudo-pedido dis-flex cor-de-fundo-modal"><img src="${produtos[i].foto}" alt=""><div class="conteudo-texto cor-de-fundo-modal"><div class="conteudo-info dis-flex cor-de-fundo-modal"><h1>${produtos[i].nome}</h1><p>${produtos[i].descricao}</p><div class="conteudo-valor cor-de-fundo-modal"><strong>${"R$  "+produtos[i].valor+",00"}</strong></div></div></div></article><section><article class="conteudo-acrescimo cor-de-fundo-modal"><div class="acrescimo cor-de-fundo-modal" ><div onclick="AC(this)" class="bot-A bot-img cor-de-fundo-modal"><button >Acréscimo </button> <img id="imag" src="imagem/expandir.svg" alt=""></div><div class="selecao cor-de-fundo-modal"><div class="selecao-esq dis-flex cor-de-fundo-modal"><span><input type="checkbox" name=""> <label for="">Carne de boi 160g &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; R$ 5,00</label></span><span><input type="checkbox" name=""> <label for="">Carne de picanha 160g &nbsp; R$ 8,00</label></span></div><div class="selecao-cen dis-flex cor-de-fundo-modal"><span><input type="checkbox" name=""> <label for="">Bacon &nbsp;&nbsp;&nbsp;&nbsp; R$ 5,00</label></span><span><input type="checkbox" name=""> <label for="">Cheddar &nbsp; R$ 4,00</label></span></div><div class="selecao-dir dis-flex cor-de-fundo-modal"><span><input type="checkbox" name=""> <label for="">Ovo &nbsp;&nbsp;&nbsp;&nbsp; R$ 2,00</label></span><span><input type="checkbox" name=""> <label for="">Salada&nbsp; R$ 2,00</label></span></div></div></div></article></section><article class="conteudo-observacao cor-de-fundo-modal"><div class="observacao" ><div onclick="OB(this)" class="bot-O bot-img cor-de-fundo-modal"><button>observação</button> <img id="image" src="imagem/expandir.svg" alt=""></div><div class="area-texto cor-de-fundo-modal"><input type="text" placeholder="Digite sua informação aqui"></div></div></article></section></section>`

            }else if(produtos[i].tipo == "suco"){

                document.querySelector("#conteudo-repetir").innerHTML+=`<section class="conteudo-dinamico cor-de-fundo-modal"><section><article class="conteudo-pedido dis-flex cor-de-fundo-modal"><img src="${produtos[i].foto}" alt=""><div class="conteudo-texto cor-de-fundo-modal"><div class="conteudo-info dis-flex cor-de-fundo-modal"><h1>${produtos[i].nome}</h1><p>${produtos[i].descricao}</p><div class="conteudo-valor cor-de-fundo-modal"><strong>${"R$  "+produtos[i].valor+",00"}</strong></div></div></div></article><section><article class="conteudo-acrescimo cor-de-fundo-modal"><div class="acrescimo cor-de-fundo-modal" ><div onclick="AC(this)" class="bot-A bot-img cor-de-fundo-modal"><button > Escolha o sabor </button> <img id="imag" src="imagem/expandir.svg" alt=""></div><div class="selecao cor-de-fundo-modal"><div class="selecao-esq dis-flex cor-de-fundo-modal"><span><input type="checkbox" name=""> <label for="">Laranja</label></span><span><input type="checkbox" name=""> <label for="">Morango</label></span></div><div class="selecao-cen dis-flex cor-de-fundo-modal"><span><input type="checkbox" name=""> <label for="">Goiaba</label></span><span><input type="checkbox" name=""> <label for="">Maracuja</label></span></div><div class="selecao-dir dis-flex cor-de-fundo-modal"><span><input type="checkbox" name=""> <label for="">Limonada Suiça</label></span><span><input type="checkbox" name=""> <label for="">Abacaxi com Hortelã</label></span></div></div></div></article></section><article class="conteudo-observacao cor-de-fundo-modal"><div class="observacao" ><div onclick="OB(this)" class="bot-O bot-img cor-de-fundo-modal"><button>observação</button> <img id="image" src="imagem/expandir.svg" alt=""></div><div class="area-texto cor-de-fundo-modal"><input type="text" placeholder="Digite sua informação aqui"></div></div></article></section></section>`

            }else{
                document.querySelector("#conteudo-repetir").innerHTML+=`<section id="teste-t"><article class="conteudo-pedido conteudo-por-sob dis-flex cor-de-fundo-modal"><img src="${produtos[i].foto}" alt=""><div class="conteudo-texto cor-de-fundo-modal"><div class="conteudo-info dis-flex cor-de-fundo-modal"><h1>${produtos[i].nome}</h1><p> ${produtos[i].descricao}</p><div class="conteudo-valor cor-de-fundo-modal"><strong>${"R$  "+produtos[i].valor+",00"}</strong></div></div></div></article></section>`
            }

            document.querySelector(".con-din-res").innerHTML+=`<div class="nomes-pedido"><h1 class="font-res">${produtos[i].quantidade}</h1><h1 class="font-res">-</h1><h1 class="esp">${produtos[i].nome}</h1><h1 class="font-res">R$&nbsp;&nbsp;<h1><h1 class="font-res">${produtos[i].quantidade*produtos[i].valor},00</h1></div>`
        }
        total += produtos[i].quantidade*produtos[i].valor
        
    }  
    document.querySelector("#total-pedido").innerText= "TOTAL  "+(total)+",00"
    

};
function fechar(){
    tela.classList.remove("aparecer");
    tela.classList.add("desaparecer");
    document.location.reload(true);
};

// -------------------------MODAL DE PAGAMMENTO-----------------------------
var telapagamento = document.getElementById("modal-fundo-pagamento")

function abrirPagamento(){
    
    tela.classList.remove("aparecer");
    tela.classList.add("desaparecer");

    telapagamento.classList.remove("desaparecer");
    telapagamento.classList.add("aparecer");


    Carrinho()
    for (let i = 0; i < carrinho.length; i++){

        if(carrinho[i]!=undefined){
            document.querySelector(".con-din-res-pag").innerHTML+=`<div class="nomes-pedido"><h1 class="font-res">${produtos[i].quantidade}</h1><h1 class="font-res">-</h1><h1 class="esp">${produtos[i].nome}</h1><h1 class="font-res">R$&nbsp;&nbsp;<h1><h1 class="font-res">${produtos[i].quantidade*produtos[i].valor},00</h1></div>`
        }
    }
    document.querySelector("#total-pedido-pagamento").innerText= "TOTAL  "+(total)+",00"

}

var carrinho = [];

function Carrinho(){
    for (let i = 0; i < numeros.length; i++){
        if(produtos[i].quantidade > 0){
            carrinho[i] = produtos[i].quantidade
            
        }
    }
}


// -----------------------------------FORMULARIO DINAMICO------------------------------------

var falso = false;

    function AC(acres){
        var ACRESCIMO = document.querySelectorAll(".bot-A")
        var tipoAC = document.querySelectorAll(".acrescimo")

        for(let i = 0; i< ACRESCIMO.length;i++){
            if(ACRESCIMO[i] == acres){
                falso == false?tipoAC[i].style.height ="15vh":tipoAC[i].style.height="4vh"
                falso == false ? falso = true : falso = false
            }
        }
    falso == false?acres.querySelector('img').style.transform = "rotate(0deg) ":acres.querySelector('img').style.transform = "rotate(180deg)";
}





function OB(obser){
   
    var OBSERVACAO = document.querySelectorAll(".bot-O")
    var obs = document.querySelectorAll(".observacao")

        for(let i = 0; i<OBSERVACAO.length;i++){
            if(OBSERVACAO[i] == obser){
                falso == false?obs[i].style.height = "18vh":obs[i].style.height = "4vh";
                falso == false ? falso = true : falso = false
            }
        }  
    falso == false?obser.querySelector('img').style.transform = "rotate(0deg) ":obser.querySelector('img').style.transform = "rotate(180deg)";
}







function cart(cartao) {
    var CARTAO = document.querySelectorAll(".teste-pag")
    var formapag = document.querySelectorAll(".pag-cartao")

    for(let i= 0; i<CARTAO.length;i++){
        if(CARTAO[i]== cartao ){
            falso == false?formapag[i].style.height ="35vh":formapag[i].style.height="4vh"
            falso == false ? falso = true : falso = false
        }
    }
}

const cartao = document.querySelectorAll(".abrir-cart")

    cartao.addEventListener("click", () => {
        var info = document.querySelectorAll(".info-cartao-cliente")
        console.log(info[1]);
        
    });

    function finalizar(){
        location.href="index.html"
        alert("Pagamento efetuado com sucesso")
    }







    function abrir1(){
        tela.classList.remove("desaparecer") 
        tela.classList.add("aparecer")
     }
     function fechar1(){
        tela.classList.remove("aparecer") 
        tela.classList.add("desaparecer")
        
      }